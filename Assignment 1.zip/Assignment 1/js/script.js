document.addEventListener('DOMContentLoaded', function () {
    let users = []; 

    const itemsPerPage = 10;
    let currentPage = 1;

    async function fetchUsersFromAPI() {
        try {
            const response = await fetch('https://randomuser.me/api/?results=53');
            const data = await response.json();
            users = data.results.map(result => ({
                name: `${result.name.first} ${result.name.last}`,
                image: result.picture.thumbnail,
                joined: result.registered.date.slice(0, 10) 
            }));
            displayUsers();
            generatePageButtons();
        } catch (error) {
            console.error('Error fetching user data: ', error);
        }
    }

    function displayUsers() {
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const currentUsers = users.slice(startIndex, endIndex);

        const userContainer = document.getElementById('userContainer');
        userContainer.innerHTML = '';

        currentUsers.forEach(user => {
            const userCard = document.createElement('div');
            userCard.classList.add('userCard');

            const userImage = document.createElement('img');
            userImage.src = user.image;
            userCard.appendChild(userImage);

            const userName = document.createElement('span');
            userName.textContent = user.name;
            userCard.appendChild(userName);

            userContainer.appendChild(userCard);
        });
    }

    function calculatePages() {
        return Math.ceil(users.length / itemsPerPage);
    }

    function generatePageButtons() {
        const totalPages = calculatePages();
        const paginationContainer = document.getElementById('paginationContainer');
        paginationContainer.innerHTML = '';

        for (let i = 1; i <= totalPages; i++) {
            const pageButton = document.createElement('button');
            pageButton.textContent = i;
            pageButton.addEventListener('click', () => {
                currentPage = i;
                displayUsers();
            });
            paginationContainer.appendChild(pageButton);
        }
    }

    fetchUsersFromAPI();
});